import seller1 from "../img/seller1.jpg";
import seller2 from "../img/seller2.jpg";
import seller3 from "../img/seller3.jpg";
import seller4 from "../img/seller4.jpg";
import seller5 from "../img/seller5.jpg";
const TopSeller = [
  { id: 1, seller_name: "Abdulazizbek", username: "Abdulazizbek802@gmail.com", imgSrc: seller1 },
  { id: 2, seller_name: "Abdulaziz", username: "Abdulaziz@gmail.com", imgSrc: seller2 },
  { id: 3, seller_name: "Azizbek", username: "Azizbek@gmail.com", imgSrc: seller3 },
  { id: 4, seller_name: "Msi", username: "MSI@gmail.com", imgSrc: seller4 },
  { id: 5, seller_name: "Abdulaziz802", username: "Abdulaziz802@gmail.com", imgSrc: seller5 },
];
export default TopSeller;