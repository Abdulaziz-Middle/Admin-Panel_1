import Menu from "./Components/Menu";
import Container from "./Components/Container";
import "./App.css";
function App() {
  return (
    <div className="App">
      <Menu />
      <Container />
    </div>
  );
}
export default App;